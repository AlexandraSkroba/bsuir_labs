#include "hash_map.h"

hash_map::hash_map()
{

}
